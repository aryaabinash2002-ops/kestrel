// extension/src/offscreen.ts
var VERSION = chrome.runtime.getManifest().version;
var SAMPLE_RATE = 16e3;
var ws = null;
var wsToken = "";
var wsPort = 0;
var reconnectTimer = null;
var reconnectDelay = 1e3;
var stream = null;
var ctx = null;
var node = null;
var capturing = false;
var pingTimer = null;
function report(status) {
  void chrome.runtime.sendMessage({ type: "offscreen-status", status }).catch(() => void 0);
}
function sendJson(msg) {
  if (ws?.readyState === WebSocket.OPEN) ws.send(JSON.stringify(msg));
}
function connect(token, port) {
  wsToken = token;
  wsPort = port;
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) return;
  report({ connection: "connecting", lastError: null });
  const socket = new WebSocket(`ws://127.0.0.1:${port}/`);
  socket.binaryType = "arraybuffer";
  ws = socket;
  socket.onopen = () => {
    reconnectDelay = 1e3;
    sendJson({ type: "hello", token, client: navigator.userAgent.includes("Edg/") ? "Edge" : navigator.userAgent.includes("Brave") ? "Brave" : "Chrome", version: VERSION });
    if (pingTimer) clearInterval(pingTimer);
    pingTimer = setInterval(() => sendJson({ type: "ping", ts: Date.now() }), 1e4);
  };
  socket.onmessage = (ev) => {
    if (typeof ev.data !== "string") return;
    let msg;
    try {
      msg = JSON.parse(ev.data);
    } catch {
      return;
    }
    if (msg.type === "welcome") {
      report({ connection: "connected", appVersion: msg.appVersion, sessionActive: msg.sessionActive, lastError: null });
      if (capturing) sendJson({ type: "capture", state: "started" });
    } else if (msg.type === "error") {
      report({ connection: msg.code === "bad-token" ? "bad-token" : "error", lastError: msg.message });
      if (msg.code === "bad-token") {
        wsToken = "";
        socket.close();
      }
    }
    void chrome.runtime.sendMessage({ type: "app-message", message: msg }).catch(() => void 0);
  };
  socket.onclose = () => {
    if (ws === socket) ws = null;
    if (pingTimer) clearInterval(pingTimer);
    pingTimer = null;
    report({ connection: wsToken ? "disconnected" : "bad-token" });
    if (wsToken && (capturing || reconnectTimer === null)) scheduleReconnect();
  };
  socket.onerror = () => {
  };
}
function scheduleReconnect() {
  if (reconnectTimer !== null || !wsToken) return;
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    if (wsToken) connect(wsToken, wsPort);
  }, reconnectDelay);
  reconnectDelay = Math.min(reconnectDelay * 2, 15e3);
}
async function start(streamId, token, port) {
  await stop(false);
  connect(token, port);
  stream = await navigator.mediaDevices.getUserMedia({
    audio: {
      // Chrome-specific constraints for tab capture.
      mandatory: { chromeMediaSource: "tab", chromeMediaSourceId: streamId }
    },
    video: false
  });
  ctx = new AudioContext({ sampleRate: SAMPLE_RATE });
  await ctx.audioWorklet.addModule(chrome.runtime.getURL("worklet.js"));
  const source = ctx.createMediaStreamSource(stream);
  source.connect(ctx.destination);
  node = new AudioWorkletNode(ctx, "pcm-capture", {
    numberOfInputs: 1,
    numberOfOutputs: 0,
    channelCount: 1,
    channelCountMode: "explicit",
    processorOptions: { chunkSize: Math.round(SAMPLE_RATE * 0.08) }
  });
  node.port.onmessage = (ev) => {
    if (ev.data.type === "chunk" && ws?.readyState === WebSocket.OPEN) ws.send(ev.data.pcm);
  };
  source.connect(node);
  for (const t of stream.getAudioTracks()) t.addEventListener("ended", () => void stop(true));
  capturing = true;
  sendJson({ type: "capture", state: "started" });
  report({ capturing: true, lastError: null });
}
async function stop(closeSocket) {
  if (capturing) sendJson({ type: "capture", state: "stopped" });
  capturing = false;
  node?.disconnect();
  node = null;
  stream?.getTracks().forEach((t) => t.stop());
  stream = null;
  await ctx?.close().catch(() => void 0);
  ctx = null;
  report({ capturing: false });
  if (closeSocket) {
    wsToken = "";
    ws?.close();
    ws = null;
  }
}
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  switch (msg.type) {
    case "offscreen-start":
      start(msg.streamId, msg.token, msg.port).then(() => reply({ ok: true })).catch((err) => {
        report({ capturing: false, lastError: err.message });
        reply({ ok: false, error: err.message });
      });
      return true;
    case "offscreen-stop":
      void stop(true).then(() => reply({ ok: true }));
      return true;
    case "offscreen-connect":
      connect(msg.token, msg.port);
      reply({ ok: true });
      return false;
    case "offscreen-forward":
      sendJson(msg.payload);
      return false;
    default:
      return false;
  }
});
