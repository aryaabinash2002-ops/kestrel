// extension/src/protocol.ts
var DEFAULT_SETTINGS = { token: "", port: 47600, autoCapture: true };
async function loadSettings() {
  const raw = await chrome.storage.local.get("settings");
  return { ...DEFAULT_SETTINGS, ...raw.settings ?? {} };
}
async function saveSettings(patch) {
  const next = { ...await loadSettings(), ...patch };
  await chrome.storage.local.set({ settings: next });
  return next;
}

// extension/src/popup/popup.ts
var $ = (id) => document.getElementById(id);
function ask(msg) {
  return chrome.runtime.sendMessage(msg);
}
function render(s) {
  const dot = $("dot");
  dot.className = "dot " + (s.connection === "connected" ? "on" : s.connection === "connecting" ? "warn" : s.connection === "disconnected" ? "" : "err");
  $("conn").textContent = s.connection === "connected" ? `Connected to Kestrel ${s.appVersion ?? ""}` : s.connection === "connecting" ? "Connecting\u2026" : s.connection === "bad-token" ? "Wrong pairing token" : s.connection === "error" ? "Connection error" : "Not connected";
  $("call").textContent = s.inCall ? "In a call" : "Not in a call";
  $("cap").textContent = s.capturing ? "Streaming to Kestrel" : "Off";
  $("cap").className = s.capturing ? "ok" : "muted";
  $("captions").textContent = s.captionsSeen ? "Reading captions" : "Off (turn on captions in Meet)";
  const err = $("error");
  err.hidden = !s.lastError;
  err.textContent = s.lastError ?? "";
  const btn = $("toggle");
  btn.textContent = s.capturing ? "Stop capture" : "Start capture";
  btn.className = s.capturing ? "" : "primary";
}
async function refresh() {
  render(await ask({ type: "get-status" }));
}
async function init() {
  const settings = await loadSettings();
  $("token").value = settings.token;
  $("port").value = String(settings.port);
  $("auto").checked = settings.autoCapture;
  if (!settings.token) $("pair").open = true;
  await refresh();
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.id && tab.url?.startsWith("https://meet.google.com/")) {
    chrome.tabs.sendMessage(tab.id, { type: "meet-query" }).catch(() => void 0);
  }
  setInterval(() => void refresh(), 1500);
}
$("toggle").addEventListener("click", async () => {
  const s = await ask({ type: "get-status" });
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  render(await ask(s.capturing ? { type: "stop-capture" } : { type: "start-capture", tabId: tab?.id }));
});
$("save").addEventListener("click", async () => {
  await saveSettings({
    token: $("token").value.trim(),
    port: Number($("port").value) || 47600,
    autoCapture: $("auto").checked
  });
  $("test").textContent = "Testing\u2026";
  await ask({ type: "test-connection" });
  setTimeout(async () => {
    const s = await ask({ type: "get-status" });
    $("test").textContent = s.connection === "connected" ? "\u2713 Connected" : s.connection === "bad-token" ? "\u2717 Wrong token" : "\u2717 Kestrel not reachable";
    render(s);
  }, 1200);
});
void init();
