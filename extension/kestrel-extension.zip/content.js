// extension/src/content/meetSelectors.ts
var SELECTORS = {
  /** Container that holds live caption entries. */
  captionsRegion: [
    'div[aria-label="Captions"]',
    'div[aria-label="Live captions"]',
    '[jsname="dsyhDe"]',
    '[jsname="tgaKEf"]',
    ".a4cQT",
    'div[role="region"][aria-live]'
  ],
  /** One caption block (speaker + running text). */
  captionEntry: ['[jsname="dsyhDe"] > div', ".nMcdL", ".TBMuR", "[data-caption-entry]", ":scope > div"],
  /** Speaker name inside a caption block. */
  captionSpeaker: [".NWpY1d", ".zs7s8d", ".KcIKyf", "[data-self-name]", "span:first-child"],
  /** Caption text inside a caption block. */
  captionText: [".bh44bd", ".iTTPOb", ".ygicle", '[jsname="YSxPC"]', "span:last-child"],
  /** Present only while in a call. */
  leaveCallButton: [
    'button[aria-label="Leave call"]',
    'button[aria-label*="Leave call"]',
    'button[aria-label*="leave call" i]',
    '[jsname="CQylAd"]',
    'button[data-tooltip*="Leave call"]'
  ],
  /** The self participant name Meet shows for the user (used to map captions to ME). */
  selfNames: ["You", "T\xFA", "Vous", "Du", "Voc\xEA", "\u3042\u306A\u305F", "\u0906\u092A"]
};
function query(candidates, root = document) {
  for (const sel of candidates) {
    try {
      const el = root.querySelector(sel);
      if (el) return el;
    } catch {
    }
  }
  return null;
}
function queryAll(candidates, root) {
  for (const sel of candidates) {
    try {
      const list = Array.from(root.querySelectorAll(sel));
      if (list.length) return list;
    } catch {
    }
  }
  return [];
}

// extension/src/content/meetCaptions.ts
function send(msg) {
  try {
    void chrome.runtime.sendMessage(msg).catch(() => void 0);
  } catch {
  }
}
var inCall = false;
function checkCall() {
  const now = !!query(SELECTORS.leaveCallButton);
  if (now !== inCall) {
    inCall = now;
    send({ type: "meet-call", state: now ? "joined" : "left", url: location.href });
  }
}
setInterval(checkCall, 1500);
window.addEventListener("beforeunload", () => {
  if (inCall) send({ type: "meet-call", state: "left", url: location.href });
});
var entries = /* @__PURE__ */ new Map();
var observer = null;
var observedRegion = null;
var FINAL_AFTER_MS = 1200;
function readEntries(region) {
  const blocks = queryAll(SELECTORS.captionEntry, region);
  const now = Date.now();
  for (const block of blocks) {
    const speaker = query(SELECTORS.captionSpeaker, block)?.textContent?.trim() ?? "";
    const text = query(SELECTORS.captionText, block)?.textContent?.trim() ?? block.textContent?.trim() ?? "";
    if (!text) continue;
    let e = entries.get(block);
    if (!e) {
      e = { speaker, text, lastChange: now, sentFinal: false, lastSentText: "" };
      entries.set(block, e);
    }
    if (e.text !== text || e.speaker !== speaker) {
      e.text = text;
      e.speaker = speaker || e.speaker;
      e.lastChange = now;
      e.sentFinal = false;
    }
    if (e.text !== e.lastSentText) {
      e.lastSentText = e.text;
      send({ type: "meet-caption", speaker: e.speaker, text: e.text, ts: now, isFinal: false });
    }
  }
  for (const [el, e] of entries) {
    if (!el.isConnected) {
      if (!e.sentFinal && e.text) send({ type: "meet-caption", speaker: e.speaker, text: e.text, ts: now, isFinal: true });
      entries.delete(el);
    }
  }
}
function flushStale() {
  const now = Date.now();
  for (const e of entries.values()) {
    if (!e.sentFinal && e.text && now - e.lastChange > FINAL_AFTER_MS) {
      e.sentFinal = true;
      send({ type: "meet-caption", speaker: e.speaker, text: e.text, ts: now, isFinal: true });
    }
  }
}
function attachCaptions() {
  const region = query(SELECTORS.captionsRegion);
  if (region === observedRegion) return;
  observer?.disconnect();
  observer = null;
  observedRegion = region;
  entries.clear();
  if (!region) return;
  observer = new MutationObserver(() => {
    try {
      readEntries(region);
    } catch {
    }
  });
  observer.observe(region, { childList: true, subtree: true, characterData: true });
}
setInterval(() => {
  try {
    attachCaptions();
    flushStale();
  } catch {
  }
}, 1e3);
chrome.runtime.onMessage.addListener((msg, _s, reply) => {
  if (msg.type === "meet-query") {
    reply({ inCall, captions: !!observedRegion });
    return false;
  }
  return false;
});
checkCall();
